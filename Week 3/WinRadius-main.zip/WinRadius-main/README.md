# [WinRadius](https://github.com/NC086/WinRadius)

[![github-stars-image](https://img.shields.io/github/stars/NC086/WinRadius.svg?label=github%20stars)](https://github.com/NC086/WinRadius)

Maybe it's the last version.

It is also the last Enterprise Edition to support 5,000 users.

- [Source Code](https://github.com/NC086/WinRadius)
